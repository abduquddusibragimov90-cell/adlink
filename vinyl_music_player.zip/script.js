const $ = (id) => document.getElementById(id);
const audio = $('audio');
const tracks = [
  { title: 'Summer Vibes', artist: 'Ocean Waves', album: 'Coastal Dreams', src: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3' },
  { title: 'Midnight Drive', artist: 'Neon Skies', album: 'City Lights', src: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3' },
  { title: 'Golden Hour', artist: 'Sunset Club', album: 'Slow Mornings', src: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3' }
];
let current = 0, shuffle = false, loop = false, userFiles = [];
const allTracks = () => [...tracks, ...userFiles];
function fmt(seconds){ if(!Number.isFinite(seconds)) return '0:00'; return `${Math.floor(seconds/60)}:${String(Math.floor(seconds%60)).padStart(2,'0')}`; }
function setTrack(index, autoplay=false){
  const list=allTracks(); current=(index+list.length)%list.length;
  const t=list[current]; $('trackTitle').textContent=t.title; $('trackArtist').textContent=t.artist; $('trackAlbum').textContent=t.album||'Your Library';
  audio.src=t.src; $('seek').value=0; $('currentTime').textContent='0:00'; $('duration').textContent='0:00';
  $('internalCount').textContent=`${tracks.length} songs`; $('totalCount').textContent=`${list.length} songs`;
  renderPlaylist(); if(autoplay) playAudio();
}
function renderPlaylist(){
  $('playlistItems').innerHTML='';
  allTracks().forEach((t,i)=>{const b=document.createElement('button');b.className='song-item'+(i===current?' current':'');b.innerHTML=`<span>${escapeHtml(t.title)}<br><small>${escapeHtml(t.artist)}</small></span><span>${i===current?'♫':'▶'}</span>`;b.addEventListener('click',()=>setTrack(i,true));$('playlistItems').appendChild(b);});
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
async function playAudio(){try{await audio.play();}catch(e){$('trackAlbum').textContent='Press play again if audio is blocked';}}
function syncPlay(){const playing=!audio.paused;$('playBtn').textContent=playing?'Ⅱ':'▶';$('playBtn').setAttribute('aria-label',playing?'Pause':'Play');$('vinyl').classList.toggle('playing',playing);document.querySelector('.turntable').classList.toggle('playing',playing);}
$('playBtn').addEventListener('click',()=>audio.paused?playAudio():audio.pause());
$('prevBtn').addEventListener('click',()=>setTrack(current-1,true));
$('nextBtn').addEventListener('click',()=>nextTrack());
function nextTrack(){const list=allTracks();setTrack(shuffle?Math.floor(Math.random()*list.length):current+1,true);}
$('loopBtn').addEventListener('click',()=>toggleLoop(!$('loopToggle').checked));
$('shuffleBtn').addEventListener('click',()=>toggleShuffle(!$('shuffleToggle').checked));
function toggleLoop(v){loop=v;$('loopToggle').checked=v;$('loopBtn').classList.toggle('active',v);audio.loop=v;}
function toggleShuffle(v){shuffle=v;$('shuffleToggle').checked=v;$('shuffleBtn').classList.toggle('active',v);}
$('loopToggle').addEventListener('change',e=>toggleLoop(e.target.checked));
$('shuffleToggle').addEventListener('change',e=>toggleShuffle(e.target.checked));
audio.addEventListener('play',syncPlay);audio.addEventListener('pause',syncPlay);audio.addEventListener('ended',()=>{if(!loop)nextTrack();});
audio.addEventListener('loadedmetadata',()=>{$('duration').textContent=fmt(audio.duration);$('seek').max=audio.duration||100;});
audio.addEventListener('timeupdate',()=>{if(!Number.isFinite(audio.duration))return;$('seek').value=audio.currentTime;$('currentTime').textContent=fmt(audio.currentTime);});
$('seek').addEventListener('input',e=>{if(Number.isFinite(audio.duration))audio.currentTime=Number(e.target.value);});
function setVolume(v){audio.volume=Number(v)/100;$('mainVolume').value=v;$('panelVolume').value=v;$('volumeText').textContent=`${v}%`;$('panelVolumeText').textContent=`Volume: ${v}%`;}
$('mainVolume').addEventListener('input',e=>setVolume(e.target.value));$('panelVolume').addEventListener('input',e=>setVolume(e.target.value));
$('darkMode').addEventListener('change',e=>document.body.classList.toggle('dark',e.target.checked));
function openSettings(){document.body.classList.add('settings-open');}
function closeSettings(){document.body.classList.remove('settings-open');}
$('settingsBtn').addEventListener('click',openSettings);$('closeSettings').addEventListener('click',closeSettings);$('shade').addEventListener('click',closeSettings);
$('libraryBtn').addEventListener('click',()=>{openSettings();$('playlist').scrollIntoView({behavior:'smooth',block:'start'});});
$('filePicker').addEventListener('change',e=>{
  [...e.target.files].forEach(file=>{const url=URL.createObjectURL(file);userFiles.push({title:file.name.replace(/\.[^.]+$/,''),artist:'Local audio file',album:'Your Library',src:url});});
  setTrack(allTracks().length-userFiles.length,true); e.target.value='';
});
document.addEventListener('keydown',e=>{if(e.code==='Space'&&!['INPUT','TEXTAREA'].includes(document.activeElement.tagName)){e.preventDefault();audio.paused?playAudio():audio.pause();}if(e.key==='Escape')closeSettings();});
setVolume(66);setTrack(0);